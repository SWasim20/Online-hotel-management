package com.room.RoomMicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoomMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
